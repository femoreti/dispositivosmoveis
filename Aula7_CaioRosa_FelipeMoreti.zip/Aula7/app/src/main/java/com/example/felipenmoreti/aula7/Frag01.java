package com.example.felipenmoreti.aula7;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

public class Frag01 extends Fragment {

    public EditText name;
    public EditText date;
    public EditText gender;
    public EditText civilState;

    public Frag01() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View view = inflater.inflate(R.layout.fragment_frag01, container, false);

        name = (EditText) view.findViewById(R.id.Nome);
        date = (EditText) view.findViewById(R.id.birth);
        gender = (EditText) view.findViewById(R.id.gender);
        civilState = (EditText) view.findViewById(R.id.civilState);

        return view;
    }

    public void onSave()
    {
        ClientData.name = name.getText().toString();
        ClientData.birthData = date.getText().toString();
        ClientData.gender = gender.getText().toString();
        ClientData.civilState = civilState.getText().toString();
    }

    public void onClear()
    {
        name.setText("");
        date.setText("");
        gender.setText("");
        civilState.setText("");
    }

}
