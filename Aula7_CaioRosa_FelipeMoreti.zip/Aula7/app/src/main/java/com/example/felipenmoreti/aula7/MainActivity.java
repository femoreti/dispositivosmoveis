package com.example.felipenmoreti.aula7;

import android.content.Intent;
import android.graphics.Color;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private ViewPager viewPager;
    private TabLayout tabLayout;
    private FloatingActionButton FAB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportActionBar().setTitle("Aula 7 - Caio, Felipe");

        viewPager = (ViewPager) findViewById(R.id.pager);
        tabLayout = (TabLayout) findViewById(R.id.tabslayout);
        FAB = (FloatingActionButton) findViewById(R.id.fabEdit);

        final SectionsPagerAdapter adapter = new SectionsPagerAdapter(getSupportFragmentManager());
        viewPager.setAdapter(adapter);
        tabLayout.setupWithViewPager(viewPager);

        tabLayout.setSelectedTabIndicatorColor(Color.rgb(255,0,0));
        tabLayout.setTabTextColors(Color.rgb(0,0,0), Color.rgb(255,255,255));

        FAB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Frag01 frag01 = (Frag01) adapter.getItem(0);
                System.out.println(frag01);
                frag01.onSave();
                frag01.onClear();
                Frag02 frag02 = (Frag02)  adapter.getItem(1);
                frag02.onSave();
                frag02.onClear();

                Snackbar.make(view, "Dados salvos com sucesso!", Snackbar.LENGTH_SHORT)
                        .setAction("Visualizar", new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                startActivity(new Intent(MainActivity.this, ShowData.class));
                            }
                        }).show();
            }
        });
    }
}
