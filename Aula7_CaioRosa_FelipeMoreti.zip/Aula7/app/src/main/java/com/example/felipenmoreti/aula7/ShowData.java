package com.example.felipenmoreti.aula7;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class ShowData extends AppCompatActivity {
    TextView dataText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_data);

        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setTitle("DADOS SALVOS");

        dataText = (TextView) findViewById(R.id.DataText);
        dataText.setText(String.format("%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n",
                ClientData.name, ClientData.birthData, ClientData.gender, ClientData.civilState,
                ClientData.Street, ClientData.number, ClientData.bairro, ClientData.city, ClientData.state));
    }
}
