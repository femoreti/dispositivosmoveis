package com.example.felipenmoreti.aula7;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;


/**
 * A simple {@link Fragment} subclass.
 */
public class Frag02 extends Fragment {

    public EditText street;
    public EditText number;
    public EditText bairro;
    public EditText city;
    public EditText state;

    public Frag02() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View view = inflater.inflate(R.layout.fragment_frag02, container, false);

        street = (EditText) view.findViewById(R.id.street);
        number = (EditText) view.findViewById(R.id.number);
        bairro = (EditText) view.findViewById(R.id.neighbor);
        city = (EditText) view.findViewById(R.id.City);
        state = (EditText) view.findViewById(R.id.State);

        return view;
    }

    public void onSave()
    {
        ClientData.Street = street.getText().toString();
        ClientData.number = number.getText().toString();
        ClientData.bairro = bairro.getText().toString();
        ClientData.city = city.getText().toString();
        ClientData.state = state.getText().toString();
    }

    public void onClear()
    {
        street  .setText("");
        number  .setText("");
        bairro  .setText("");
        city  .setText("");
        state.setText("");
    }
}
