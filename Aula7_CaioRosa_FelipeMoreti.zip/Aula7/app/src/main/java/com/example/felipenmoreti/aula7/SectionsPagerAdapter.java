package com.example.felipenmoreti.aula7;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import  android.support.v4.app.FragmentStatePagerAdapter;

public class SectionsPagerAdapter extends FragmentStatePagerAdapter {

    private Fragment frag01 = new Frag01();
    private Fragment frag02 = new Frag02();

    public SectionsPagerAdapter(FragmentManager fm) {
        super(fm);


    }
    @Override
    public Fragment getItem(int i) {
        if(i == 0)
        {
            return frag01;
        }
        if(i == 1)
        {
            return frag02;
        }
        return null;
    }
    @Override
    public int getCount() {
        return 2;
    }
    @Override
    public CharSequence getPageTitle(int position) {
        if(position == 0)
            return "Dados";
        else if(position == 1)
            return "Endereço";
        return "";
    }

}
