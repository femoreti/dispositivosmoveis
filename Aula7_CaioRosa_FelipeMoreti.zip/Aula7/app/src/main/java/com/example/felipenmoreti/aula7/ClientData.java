package com.example.felipenmoreti.aula7;

public final class ClientData {
    public static String name;
    public static String birthData;
    public static String gender;
    public static String civilState;
    public static String Street;
    public static String number;
    public static String bairro;
    public static String city;
    public static String state;
}
