package com.example.felipenmoreti.exercicio_aula9;

import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {
    private ViewGroup mensagens;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().setTitle("ADO aula 9 - Caio Rosa e Felipe Moreti");

        mensagens = (ViewGroup)findViewById(R.id.container);

        callAPI();
    }

    private void addItem(Product p) {
        CardView cardView = (CardView) LayoutInflater.from(this)
                .inflate(R.layout.productcard, mensagens, false);
        TextView titulo = (TextView) cardView.findViewById(R.id.Nome);
        TextView preco = (TextView) cardView.findViewById(R.id.preco);
        TextView desconto = (TextView) cardView.findViewById(R.id.desconto);
        ImageView imageView = (ImageView) cardView.findViewById(R.id.Foto);
        titulo.setText(p.nomeProduto);
        preco.setText("R$: " + p.precProduto);
        desconto.setText(("Você economiza: " + p.descontoPromocao));

        ImageLoader imageLoader = ImageLoader.getInstance();
        imageLoader.init(ImageLoaderConfiguration.createDefault(this));
        DisplayImageOptions options = new DisplayImageOptions.Builder()
                .showImageOnLoading(R.drawable.loading)
                .cacheInMemory(true)
                .cacheOnDisk(true)
                .build();

        String url = "https://oficinacordova.azurewebsites.net/android/rest/produto/image/" + p.idProduto.toString();
        imageLoader.displayImage(url, imageView, options);

        mensagens.addView(cardView);
    }

    private void showDialog(String val, String title) {
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setMessage(val);
        builder.setTitle(title);
        builder.setCancelable(false);
        builder.setPositiveButton("OK", null);
        AlertDialog dialog = builder.create();
        dialog.show();
    }


    private void callAPI()
    {
        System.out.println("### CALL API");
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://oficinacordova.azurewebsites.net")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        IApiProducts prodAPI = retrofit.create(IApiProducts.class);

        Callback<List<Product>> callbackProds = new Callback<List<Product>>() {
            @Override
            public void onResponse(Call<List<Product>> call, Response<List<Product>> response) {
                List<Product> prods = response.body();

                if(response.isSuccessful() && prods != null)
                {
                    //criar cards aqui
                    for(int i = 0; i < prods.size(); i++)
                    {
                        addItem((prods.get(i)));
                    }
                }
            }

            @Override
            public void onFailure(Call<List<Product>> call, Throwable t) {
                t.printStackTrace();
                showDialog("Erro ao carregar produtos", "erro!");
            }
        };

        final Call<List<Product>> prodsCall = prodAPI.getProducts();
        prodsCall.enqueue(callbackProds);

    }
}
