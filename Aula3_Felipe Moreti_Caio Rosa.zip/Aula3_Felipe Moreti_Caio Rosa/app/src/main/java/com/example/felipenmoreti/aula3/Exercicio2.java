package com.example.felipenmoreti.aula3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Exercicio2 extends AppCompatActivity {
    TextView txtResult;
    EditText txtA, txtB;
    Button btnNext, btnResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercicio2);
        getSupportActionBar().setTitle("Exercicio 2");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        txtResult = (TextView) findViewById(R.id.etResult);
        txtA = (EditText) findViewById(R.id.etValue1);
        txtB = (EditText) findViewById(R.id.etValue2);
        btnNext = (Button) findViewById(R.id.btnNext);

        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Exercicio2.this, Exercicio3.class));
            }
        });

        btnResult = (Button) findViewById(R.id.btnResult);

        btnResult.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                txtResult.setText(Double.toString(Double.parseDouble(txtA.getText().toString()) + Double.parseDouble(txtB.getText().toString())));
            }
        });
    }
}
