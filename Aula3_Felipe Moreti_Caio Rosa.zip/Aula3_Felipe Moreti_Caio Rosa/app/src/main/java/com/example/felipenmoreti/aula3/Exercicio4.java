package com.example.felipenmoreti.aula3;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

public class Exercicio4 extends AppCompatActivity {

    EditText txtA,txtB;
    TextView txtResult;
    RadioButton rbSum, rbSub, rbMult, rbDiv;
    Button btnResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercicio4);
        getSupportActionBar().setTitle("Exercicio 4");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        txtA = (EditText) findViewById(R.id.etValue1);
        txtB = (EditText) findViewById(R.id.etValue2);

        txtResult = (TextView) findViewById(R.id.etResult);

        rbSum = (RadioButton) findViewById(R.id.rbSoma);
        rbSub = (RadioButton) findViewById(R.id.rbSubtracao);
        rbMult = (RadioButton) findViewById(R.id.rbMult);
        rbDiv = (RadioButton) findViewById(R.id.rbDiv);

        btnResult = (Button) findViewById(R.id.btnResult);
        btnResult.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Double a = Double.parseDouble(txtA.getText().toString());
                Double b = Double.parseDouble(txtB.getText().toString());
                Double result = 0.0;

                if(rbSum.isChecked())
                    result = a + b;
                else if(rbSub.isChecked())
                    result = a - b;
                else if(rbMult.isChecked())
                    result = a * b;
                else if(rbDiv.isChecked())
                    result = a / b;

                txtResult.setText(Double.toString(result));
            }
        });
    }
}
