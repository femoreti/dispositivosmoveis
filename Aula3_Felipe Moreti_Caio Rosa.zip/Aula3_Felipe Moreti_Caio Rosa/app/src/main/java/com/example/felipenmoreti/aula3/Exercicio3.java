package com.example.felipenmoreti.aula3;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;

public class Exercicio3 extends AppCompatActivity {
    EditText etName;
    Button btnNext, btnShow;
    RadioButton rbSolteiro, rbCasado, rbMasc, rbFem;

    private void showDialog()
    {
        String strCivil = "", strGen = "";
        if(rbSolteiro.isChecked())
            strCivil = "solteiro";
        else if(rbCasado.isChecked())
            strCivil = "casado";

        if(rbMasc.isChecked())
            strGen = "Sr.";
        else if(rbFem.isChecked())
            strGen = "Sra.";

        AlertDialog aDialog = new AlertDialog.Builder(Exercicio3.this)
                .setTitle("Exercicio 3")
                .setMessage("Olá, " + strGen + " " + etName.getText() + ", " + strCivil)
                .setPositiveButton("Close", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // continue with delete
                    }
                })
                .show();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercicio3);
        getSupportActionBar().setTitle("Exercicio 3");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        etName = (EditText) findViewById(R.id.etName);
        rbSolteiro = (RadioButton) findViewById(R.id.rbSolteiro);
        rbCasado = (RadioButton) findViewById(R.id.rbCasado);
        rbMasc = (RadioButton) findViewById(R.id.rbMasculino);
        rbFem = (RadioButton) findViewById(R.id.rbFeminino);

        btnNext = (Button) findViewById(R.id.btnNext);
        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Exercicio3.this, Exercicio4.class));
            }
        });

        btnShow = (Button) findViewById(R.id.btnShow);
        btnShow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDialog();
            }
        });
    }
}
