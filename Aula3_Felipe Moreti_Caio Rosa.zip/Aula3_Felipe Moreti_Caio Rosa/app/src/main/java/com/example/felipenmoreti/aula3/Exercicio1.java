package com.example.felipenmoreti.aula3;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Exercicio1 extends AppCompatActivity {

    EditText etName, etLastName;
    Button btnOk, btnNext;

    private void showDialog()
    {
        AlertDialog aDialog = new AlertDialog.Builder(Exercicio1.this)
                .setTitle("Show user name")
                .setMessage("Olá, " + etName.getText() + " " + etLastName.getText())
                .setPositiveButton("Close", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // continue with delete
                    }
                })
                .show();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercicio1);
        getSupportActionBar().setTitle("Exercicio 1");

        etName = (EditText) findViewById(R.id.etName);
        etLastName = (EditText) findViewById(R.id.etLastName);
        btnOk = (Button) findViewById(R.id.btnOk);
        btnNext = (Button) findViewById(R.id.btnNext);

        btnOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDialog();
            }
        });

        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Exercicio1.this, Exercicio2.class));
            }
        });
    }
}
