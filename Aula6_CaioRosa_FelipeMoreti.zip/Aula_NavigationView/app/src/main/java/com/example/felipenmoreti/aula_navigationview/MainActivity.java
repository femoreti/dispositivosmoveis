package com.example.felipenmoreti.aula_navigationview;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v4.widget.DrawerLayout;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

public class MainActivity extends AppCompatActivity {
    private NavigationView navigationView;
    private DrawerLayout drawerLayout;
    private ActionBarDrawerToggle actionBarDrawerToggle;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setTitle("Aula6_Exercicios");

        navigationView = (NavigationView) findViewById(R.id.navigation_view);


        getSupportFragmentManager().beginTransaction().replace(R.id.frag_container, new Fragment01()).commit();

        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                if(menuItem.isChecked()){
                    menuItem.setChecked(false);
                }
                else {
                    menuItem.setChecked(true);
                }

                drawerLayout.closeDrawers();

                if(menuItem.getItemId() == R.id.action_settings){
                    getSupportFragmentManager().beginTransaction().replace(R.id.frag_container, new Fragment01()).commit();

                    return true;
                }

                else if(menuItem.getItemId() == R.id.action_settings1){
                    getSupportFragmentManager().beginTransaction().replace(R.id.frag_container, new Fragment2()).commit();

                    return true;
                }

                else if(menuItem.getItemId() == R.id.action_settings2){
                    getSupportFragmentManager().beginTransaction().replace(R.id.frag_container, new Fragment3()).commit();

                    return true;
                }
                return false;
            }
        });

        drawerLayout = (DrawerLayout) findViewById(R.id.drawer);
        actionBarDrawerToggle =
                new ActionBarDrawerToggle(this, drawerLayout,
                        R.string.openDrawer, R.string.closeDrawer) {
                };
        drawerLayout.setDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (actionBarDrawerToggle.onOptionsItemSelected(item)) {
            return true;
        }
        if(item.getItemId() == R.id.about)
        {
            startActivity(new Intent(MainActivity.this, Sobre.class));
            return true;
        }
        else if(item.getItemId() == R.id.leave)
        {
            System.exit(0);

            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_about, menu);
        return true;
    }
}
