package com.example.felipenmoreti.aula_navigationview;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Sobre extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getSupportActionBar().setHomeButtonEnabled(true);

        setContentView(R.layout.activity_sobre);
    }
}
